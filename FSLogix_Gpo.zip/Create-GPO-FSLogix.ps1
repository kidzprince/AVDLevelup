﻿Copy-Item -Path 'C:\Windows\PolicyDefinitions' -Destination 'C:\SYSVOL\domain\Policies' -Recurse
Copy-Item -Path '.\fslogix.admx' -Destination 'C:\SYSVOL\domain\Policies\PolicyDefinitions'
Copy-Item -Path '.\fslogix.adml' -Destination 'C:\SYSVOL\domain\Policies\PolicyDefinitions\en-US'
New-Item -Path 'c:\temp3' -ItemType Directory
Copy-Item -Path '.\{9DCB5E1C-1000-492B-8C16-5049B265F750}' -Destination 'C:\temp3'-Recurse
New-GPO -Name "Machine-FSLogix"
Import-GPO -TargetName "Machine-FSLogix" -Path "c:\temp3\" -BackupId "9dcb5e1c-1000-492b-8c16-5049b265f750"
Remove-Item -Path 'c:\temp3' -Force -Confirm:$false -Recurse